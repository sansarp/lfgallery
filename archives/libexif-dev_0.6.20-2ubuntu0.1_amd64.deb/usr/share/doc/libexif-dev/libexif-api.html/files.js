var files =
[
    [ "libexif/_stdint.h", null, null ],
    [ "libexif/exif-byte-order.h", null, null ],
    [ "libexif/exif-content.h", "exif-content_8h.html", "exif-content_8h" ],
    [ "libexif/exif-data-type.h", null, null ],
    [ "libexif/exif-data.h", "exif-data_8h.html", "exif-data_8h" ],
    [ "libexif/exif-entry.h", "exif-entry_8h.html", "exif-entry_8h" ],
    [ "libexif/exif-format.h", "exif-format_8h.html", "exif-format_8h" ],
    [ "libexif/exif-ifd.h", null, null ],
    [ "libexif/exif-loader.h", "exif-loader_8h.html", "exif-loader_8h" ],
    [ "libexif/exif-log.h", "exif-log_8h.html", "exif-log_8h" ],
    [ "libexif/exif-mem.h", "exif-mem_8h.html", "exif-mem_8h" ],
    [ "libexif/exif-mnote-data-priv.h", null, null ],
    [ "libexif/exif-mnote-data.h", "exif-mnote-data_8h.html", "exif-mnote-data_8h" ],
    [ "libexif/exif-system.h", "exif-system_8h.html", "exif-system_8h" ],
    [ "libexif/exif-tag.h", "exif-tag_8h.html", "exif-tag_8h" ],
    [ "libexif/exif-utils.h", "exif-utils_8h.html", "exif-utils_8h" ],
    [ "libexif/exif.h", "exif_8h.html", null ],
    [ "libexif/i18n.h", null, null ]
];