var structExifSRational =
[
    [ "denominator", "structExifSRational.html#add1d6a0cb9f022dba76e984c7dbc65d7", null ],
    [ "numerator", "structExifSRational.html#aa815271c1e4470a0179a4329789c79be", null ]
];