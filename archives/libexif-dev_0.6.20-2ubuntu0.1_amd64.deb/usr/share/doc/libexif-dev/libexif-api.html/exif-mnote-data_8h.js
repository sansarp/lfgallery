var exif-mnote-data_8h =
[
    [ "ExifMnoteData", "exif-mnote-data_8h.html#ad274692c704f570122329ef1ab32ed31", null ],
    [ "exif_mnote_data_count", "exif-mnote-data_8h.html#af61fbda7c717e86991b0eccf6976a5f4", null ],
    [ "exif_mnote_data_get_description", "exif-mnote-data_8h.html#aa21ac7dd1784e892ec482fe037fc646b", null ],
    [ "exif_mnote_data_get_id", "exif-mnote-data_8h.html#a981bab235db2e156216d5cc43f48cac7", null ],
    [ "exif_mnote_data_get_name", "exif-mnote-data_8h.html#a921ea2f4583325653d2207c6f1d98742", null ],
    [ "exif_mnote_data_get_title", "exif-mnote-data_8h.html#abdf581cdc7ce672b44978ef993f22b78", null ],
    [ "exif_mnote_data_get_value", "exif-mnote-data_8h.html#a56299b268a29ea7fa1301952cfe32ca4", null ],
    [ "exif_mnote_data_load", "exif-mnote-data_8h.html#aee48077668022309e4ba26da61c48334", null ],
    [ "exif_mnote_data_log", "exif-mnote-data_8h.html#a9a6093f4cd64a11919f254851e54d92c", null ],
    [ "exif_mnote_data_ref", "exif-mnote-data_8h.html#a6e4fab705cb33adde53dfff211dcd03c", null ],
    [ "exif_mnote_data_save", "exif-mnote-data_8h.html#a79ac0114a43394bbf8ff490277762af3", null ],
    [ "exif_mnote_data_unref", "exif-mnote-data_8h.html#ac51e0514ec846838697a460a24bb73fb", null ]
];