var pages =
[
    [ "Deprecated List", "deprecated.html", null ],
    [ "Bug List", "bug.html", null ]
];