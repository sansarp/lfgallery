var exif-format_8h =
[
    [ "ExifFormat", "exif-format_8h.html#a761152047d73b4a9fcdc4e2051b817d2", null ],
    [ "exif_format_get_name", "exif-format_8h.html#a59375a5939c716b826311c22571680f3", null ],
    [ "exif_format_get_size", "exif-format_8h.html#a924038efe0cd8ebade8f44619dd794f3", null ]
];