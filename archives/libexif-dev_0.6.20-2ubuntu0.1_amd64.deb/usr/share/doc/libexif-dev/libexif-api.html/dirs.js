var dirs =
[
    [ "libexif", "dir_72b83a5801d1473827f87860791d7f5a.html", null ]
];