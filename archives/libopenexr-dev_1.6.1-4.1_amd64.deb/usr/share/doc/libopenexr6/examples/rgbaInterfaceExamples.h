
void rgbaInterfaceExamples ();

