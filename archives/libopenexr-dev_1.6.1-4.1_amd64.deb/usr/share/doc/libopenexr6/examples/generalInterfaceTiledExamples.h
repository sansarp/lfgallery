
void generalInterfaceTiledExamples ();

